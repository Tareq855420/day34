@extends('master')

@section('title')
    Add Product
@endsection

@section('body')

    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="card card-header">Add Product</div>
                        <div class="card card-body">
                            <form action="" method="POST">
                                <div class="form-group row">
                                    <label class="col-md-3">First Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="firstName" class="form-control" name="first_Name">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-md-3">Last Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="lastName" class="form-control" name="last_Name">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-md-3">Full Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="fullName" class="form-control" name="full_Name">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="" class="col-md-9 col-form-label"></label>
                                    <div class="col-md-12">
                                        <input type="button" class="btn btn-block btn-success" onclick="makeFullName()" name="btn" value="Submit" >
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection

    <script>

        function makeFullName()
        {
            var firstName = document.getElementById('firstName').value;
            var lastName = document.getElementById('lastName').value;
            var fullName = firstName+' '+lastName;
            document.getElementById('fullName').value = fullName;
        }

    </script>

    <script src="{{ asset('/assets/js/jquery-3.6.0.min.js') }}"></script>
    <script src="{{ asset('/assets/js/bootstrap.bundle.js') }}"></script>
</body>
</html>
