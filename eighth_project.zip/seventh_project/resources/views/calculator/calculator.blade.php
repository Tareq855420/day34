@extends('master')

@section('title')
    Add Product
@endsection

@section('body')

    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="card card-header">Calculator</div>
                        <div class="card card-body">
                            <form action="" method="POST">
                                <div class="form-group row">
                                    <label class="col-md-3">First Number</label>
                                    <div class="col-md-9">
                                        <input type="number" id="firstNumber" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-md-3">Last Number</label>
                                    <div class="col-md-9">
                                        <input type="number" id="lastNumber" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-md-3">Select Operator</label>
                                    <div class="col-md-9">
                                        <label><input type="radio" name="operator" value="+">+</label>
                                        <label><input type="radio" name="operator" value="-">-</label>
                                        <label><input type="radio" name="operator" value="*">*</label>
                                        <label><input type="radio" name="operator" value="/">/</label>
                                        <label><input type="radio" name="operator" value="%">%</label>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-md-3">Result</label>
                                    <div class="col-md-9">
                                        <input type="number" id="result" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="" class="col-md-9 col-form-label"></label>
                                    <div class="col-md-12">
                                        <input type="button" class="btn btn-block btn-success" id="submitBtn" value="Submit" >
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>

        var submitBtn = document.getElementById('submitBtn');
        submitBtn.onclick = function () {
            var data = document.getElementsByName('operator');
            var i;
            var operator;
            var result;
            for (i = 0; i < data.length; i++)
            {
                if(data[i].checked == true)
                {
                    operator = data[i].value;
                    break;
                }
            }
            var firstNumber = Number(document.getElementById('firstNumber').value);
            var lastNumber = Number(document.getElementById('lastNumber').value);

            switch (operator)
            {
                case '+':
                result = firstNumber + lastNumber;
                break;

                case '-':
                result = firstNumber - lastNumber;
                break;

                case '*':
                result = firstNumber * lastNumber;
                break;

                case '/':
                result = firstNumber / lastNumber;
                break;

                case '%':
                result = firstNumber % lastNumber;
                break;
            }
            document.getElementById('result').value = result;
        }

    </script>

@endsection

<script src="{{ asset('/assets/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('/assets/js/bootstrap.bundle.js') }}"></script>
</body>
</html>
